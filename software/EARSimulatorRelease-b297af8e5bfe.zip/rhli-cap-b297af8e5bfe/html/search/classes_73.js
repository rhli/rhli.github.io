var searchData=
[
  ['switch',['Switch',['../classSwitch.html',1,'']]]
];
