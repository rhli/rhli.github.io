var searchData=
[
  ['trafficmanager',['trafficManager',['../classtrafficManager.html#a95c2c77f522905085295f23d4cd49a64',1,'trafficManager']]]
];
